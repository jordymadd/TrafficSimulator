package exercise1;
import java.util.Random;
import greenfoot.Actor;
import greenfoot.GreenfootImage;

public class Car extends Actor implements TrafficLightSensor{
	
	private String[] carImgPath = {"images/topCarBlue.png", "images/topCarPurple.png",
			"images/topCarYellow.png","images/topCarRed.png"};

	private Speed speed = Speed.REGULAR; 
	private Direction direction; 

	public Car(Direction direction){
		this.direction = direction; 
		setRotation(direction.getRotation());
		Random rand = new Random(); 
		int randomNum = rand.nextInt(4); 
		GreenfootImage image = new GreenfootImage(carImgPath[0]); 
		switch (randomNum) {
		case 0 : image = new GreenfootImage(carImgPath[0]);
		break;
		case 1 : image = new GreenfootImage(carImgPath[1]);
		break;
		case 2 : image = new GreenfootImage(carImgPath[2]);
		break;
		case 3 : image = new GreenfootImage(carImgPath[3]); 
		break;
		}
		this.setImage(image);
	}

	public int Random(int length){
		Random rand = new Random(); 
		int randomNum = rand.nextInt(length); 
		return randomNum;
	}


	public void act(){
		if(speed==Speed.REGULAR){
			move(speed.getSpeed());
		}
		else if(speed==Speed.SLOW){
			move(speed.getSpeed());
		}
		else if(speed==Speed.STOP){
			move(speed.getSpeed());
		}
		handleWrap();
	}


	private void handleWrap() {
		if(isAtEdge()){
			switch (this.getRotation()) {
			case 0 : setLocation(0, getY());
			break;
			case 90 : setLocation(getX(), 0);
			break;
			case 180 :setLocation(TrafficWorld.WIDTH, getY());
			break;
			case 270 :setLocation(getX(), TrafficWorld.HEIGHT);
			break;

			}
		}
	}


	public enum Speed{
		STOP(0), 
		SLOW(2), 
		REGULAR(5);
		private int speed; 

		public int getSpeed(){
			return speed; 
		}

		private Speed(int speed){
			this.speed = speed; 
		}


	}

	
	@Override
	public void nearIntersection(Intersection intersection) { 
		if (intersection.isGreen(direction)){
			speed =Speed.REGULAR; 
		}
		else if (intersection.isYellow(direction)){
			speed =Speed.SLOW; 
		}
		else if (intersection.isRed(direction)){
			speed =Speed.SLOW; 
		}
		//I can use this to print out to console what the position of the car is relative to the intersection
//		System.out.println("Near");
	}

	@Override
	public void inInterSection(Intersection intersection) {
		if (intersection.isGreen(direction)){
			speed =Speed.REGULAR; 
		}
		else if (intersection.isYellow(direction)){
			speed =Speed.REGULAR; 
		}
		else if (intersection.isRed(direction)){
			speed =Speed.STOP; 
		}
		//I can use this to print out to console what the position of the car is relative to the intersection
//		System.out.println("In");
	}

	@Override
	public void leavingIntersection(Intersection intersection) {
		if (intersection.isGreen(direction)){
			speed =Speed.REGULAR; 
		}
		else if (intersection.isYellow(direction)){
			speed =Speed.REGULAR; 
		}
		else if (intersection.isRed(direction)){
			speed =Speed.REGULAR; 
		}
		//I can use this to print out to console what the position of the car is relative to the intersection
//		System.out.println("Out");
	}

	@Override
	public Direction getDirection() {
		return direction;
	}
	
}
